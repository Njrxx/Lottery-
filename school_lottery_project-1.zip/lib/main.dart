import 'package:flutter/material.dart';

void main() {
  runApp(SchoolLotteryApp());
}

class SchoolLotteryApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'School Lottery',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: LotteryHomePage(),
    );
  }
}

class LotteryHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('School Lottery'),
      ),
      body: Center(
        child: Text(
          'Welcome to the School Lottery!',
          style: TextStyle(fontSize: 20),
        ),
      ),
    );
  }
}
